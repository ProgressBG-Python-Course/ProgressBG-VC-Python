first_names  = ("ivan" ,"maria" , "prtar")
sur_name = ("ivanov" , "popova" , "petrov")
names = first_names[0], sur_name[0] ,first_names[1] ,sur_name[1] , first_names[2], sur_name[2]
print(names)
