words = ["dog" , "talant" , "loop" , "aria" , "tent" , "choice"]

for i in words:
        if i[0][0] == i[0][-1]:
         print (words) 
         break
         
        
         
        
    
