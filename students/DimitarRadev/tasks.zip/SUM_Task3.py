sum = 0
for i in range(1000,1201, 2 ):
    sum += i
    print(sum)
