
Num_tries = input("How many names are you going to enter:")
tries = 0
list = []
while tries < 3:
    y=str(input("Enter a name, please:\n"))
    list.append(y)
    tries += 1
    if tries == 3:
        print("The names you've entered are:" , list)