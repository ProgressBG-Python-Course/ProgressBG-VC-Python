first_names  = ("ivan" ,"maria" , "prtar")
sur_names = ("ivanov" , "popova" , "petrov")
names  = first_names + sur_names
print(names)