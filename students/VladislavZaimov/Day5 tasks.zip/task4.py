words = ["dog", "talent", "loop", "aria", "tent", "choice"]

for w in words:
    if w[0] == w[-1]:
        print(w)

