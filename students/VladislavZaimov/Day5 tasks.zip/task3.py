
# version 1

suma = 0
for i in range(1000, 1201, 2):
    suma += i
print(suma)


# version 2

print(sum(range(1000, 1201, 2)))

